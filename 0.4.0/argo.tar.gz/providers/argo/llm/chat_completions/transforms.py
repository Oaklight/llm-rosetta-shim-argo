"""Argo OpenAI Chat schema transforms.

Request-side (post_ir_transforms) — body-level
-------------------------------------------
- ``rename_field("max_tokens", "max_completion_tokens", pattern=r"^gemini")``:
  converts ``max_tokens`` to ``max_completion_tokens`` for Gemini models
  only — Gemini via Argo rejects ``max_tokens``, while Claude via Argo
  rejects ``max_completion_tokens`` alone (500 "Streaming is required").
- ``replace_message_field("role", "developer", "system")``: downgrades
  the ``developer`` role (OpenAI 2024-12-17+) to ``system`` for upstream
  gateways that don't support it.
- ``default_message_field("content", "")``: replaces ``content: null``
  with an empty string — upstream gateways (e.g. Argo Gemini) crash on
  null content when iterating message bodies.
- ``strip_fields_for_model(..., "temperature", "top_p", "top_k")``: strips
  sampling params for models that reject them on the OAI Chat endpoint.
  Covers GPT-5 base/5.5/5.6, Claude Opus 4.7, Claude Sonnet 5.
- ``flatten_system_content(pattern=r"^gemini")``: flattens system message
  content arrays to plain strings for Gemini models, which don't handle
  structured content in system messages.

Request-side (ir_transforms) — IR-level
-----------------------------------------
- ``hoist_late_system_messages()``: rewrite mid-conversation system messages
  as user-role envelopes for prompt cache prefix stability.
- ``truncate_images(50, pattern=r"^(gpt|o\\d)")``: enforce 50-image limit
  for GPT/o* models; Gemini and Claude pass through untouched.
- ``unwind_parallel_tool_calls(pattern=r"^gemini")``: split parallel tool
  calls into sequential pairs for Gemini models through Argo.
"""

from llm_rosetta.contracts.transform import (
    default_message_field,
    flatten_system_content,
    hoist_late_system_messages,
    rename_field,
    replace_message_field,
    strip_fields_for_model,
    truncate_images,
    unwind_parallel_tool_calls,
)

# Re-export shared Argo model list transform for convention-based hook
# discovery by the shim loader.
from ...model_utils import model_list_transform  # noqa: F401

post_ir_transforms = (
    rename_field("max_tokens", "max_completion_tokens", pattern=r"^gemini"),
    replace_message_field("role", "developer", "system"),
    default_message_field("content", ""),
    strip_fields_for_model(
        r"^(gpt5(nano|mini)?$|gpt5[56]|claudeopus47$|claudesonnet5$)",
        "temperature",
        "top_p",
        "top_k",
    ),
    flatten_system_content(pattern=r"^gemini"),
)
pre_ir_transforms = ()
ir_transforms = (
    hoist_late_system_messages(),
    truncate_images(50, pattern=r"^(gpt|o\d)"),
    unwind_parallel_tool_calls(pattern=r"^gemini"),
)
